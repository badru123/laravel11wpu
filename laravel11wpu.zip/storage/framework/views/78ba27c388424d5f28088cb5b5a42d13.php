<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH /home/lms.edupb4k.com/chirper/vendor/jeroennoten/laravel-adminlte/src/../resources/views/partials/footer/footer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content_body'); ?>
<div class="card">
    <form method='get' action="https://lazis.pb4k.org/zis/index">
        <div class="input-group">
            <input class="form-control form-control-border" type='text' name='search' value='' placeholder="<?php echo e(__('Search Chirps')); ?>">
            <div class="input-group-append">
                <button type='submit' name='submit' value='submit' class="btn btn-default"> <i class="fas fa-search"></i><?php echo e(__('Search')); ?></button>
            </div>
        </div>
    </form>
</div>
    <div class="card card-primary card-outline">
        <div class="card-body">
        <form method="POST" action="<?php echo e(route('chirps.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala47f947a90f7125ced2d0aa2e9c7c7d7 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Textarea::resolve(['name' => 'message','label' => 'Chirp','igroupSize' => 'sm','labelClass' => 'text-primary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminlte-textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\JeroenNoten\LaravelAdminLte\View\Components\Form\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['rows' => '5','placeholder' => ''.e(__('What\'s on your mind?')).'']); ?>
                <?php echo e(old('message')); ?>

             <?php $__env->slot('appendSlot', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['type' => 'submit','theme' => 'primary','icon' => 'fas fa-paper-plane','label' => ''.e(__('Chirp')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\JeroenNoten\LaravelAdminLte\View\Components\Form\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala47f947a90f7125ced2d0aa2e9c7c7d7)): ?>
<?php $attributes = $__attributesOriginala47f947a90f7125ced2d0aa2e9c7c7d7; ?>
<?php unset($__attributesOriginala47f947a90f7125ced2d0aa2e9c7c7d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7)): ?>
<?php $component = $__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7; ?>
<?php unset($__componentOriginala47f947a90f7125ced2d0aa2e9c7c7d7); ?>
<?php endif; ?>
        </form>
        </div>
    </div>
    <?php echo e($chirps->links()); ?>

            <?php $__currentLoopData = $chirps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chirp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal0f735d5fb4b8fa83ff0f808815951f9c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f735d5fb4b8fa83ff0f808815951f9c = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::resolve(['theme' => 'primary'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php if($chirp->user->is(auth()->user())): ?>
                    <div class="float-right card-tools">
                        <div class="btn-group">
                           <button type="button" class="btn btn-light btn-sm" data-toggle="dropdown" data-offset="-52">
                             <i class="fas fa-ellipsis-v"></i>
                           </button>
                           <div class="dropdown-menu" role="menu">
                               <a href="<?php echo e(route('chirps.edit', $chirp)); ?>" class="dropdown-item"> Edit</a>
                               <form method="POST" action="<?php echo e(route('chirps.destroy', $chirp)); ?>">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('delete'); ?>
                               <button href="route('chirps.destroy', $chirp)" onclick="event.preventDefault(); this.closest('form).submit();" class="dropdown-item"> Hapus</button>
                               </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <p>
                        <b><?php echo e($chirp->user->name); ?></b> <span class="ml-2"><small class="text-muted"><?php echo e($chirp->created_at->diffForHumans()); ?></small></span>
                        <?php if (! ($chirp->created_at->eq($chirp->updated_at))): ?>
                        <small class="text-muted ml-2"> &middot; <?php echo e(__('edited')); ?></small>
                        <?php endif; ?>
                    </p>
                    <?php echo e($chirp->message); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f735d5fb4b8fa83ff0f808815951f9c)): ?>
<?php $attributes = $__attributesOriginal0f735d5fb4b8fa83ff0f808815951f9c; ?>
<?php unset($__attributesOriginal0f735d5fb4b8fa83ff0f808815951f9c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f735d5fb4b8fa83ff0f808815951f9c)): ?>
<?php $component = $__componentOriginal0f735d5fb4b8fa83ff0f808815951f9c; ?>
<?php unset($__componentOriginal0f735d5fb4b8fa83ff0f808815951f9c); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="justify-content-center">
            <?php echo e($chirps->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lms.edupb4k.com/chirper/resources/views/chirps/index.blade.php ENDPATH**/ ?>